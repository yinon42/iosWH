//
//  IOS_25B_HW1_2App.swift
//  IOS_25B_HW1&2
//
//  Created by Student21 on 20/05/2025.
//

import SwiftUI

@main
struct IOS_25B_HW1_2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
