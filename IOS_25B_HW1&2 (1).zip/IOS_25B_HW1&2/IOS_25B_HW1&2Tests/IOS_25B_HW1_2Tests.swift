//
//  IOS_25B_HW1_2Tests.swift
//  IOS_25B_HW1&2Tests
//
//  Created by Student21 on 20/05/2025.
//

import Testing
@testable import IOS_25B_HW1_2

struct IOS_25B_HW1_2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
