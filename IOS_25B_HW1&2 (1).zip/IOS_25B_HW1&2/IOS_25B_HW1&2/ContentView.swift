//
//  ContentView.swift
//  IOS_25B_HW1&2
//
//  Created by Student21 on 20/05/2025.
//

import SwiftUI

struct ContentView: View {
    @AppStorage("userName") var userName: String = ""
    @AppStorage("userSide") var userSide: String = "West" // East או West

    @State private var showNameInput = false
    @State private var navigateToGame = false
    @StateObject private var locationManager = LocationManager()

    let centerLongitude = 34.817546 // נקודת האמצע בין מזרח למערב

    var body: some View {
        NavigationStack {
            VStack {
                Spacer().frame(height: 40)

                // כפתור הכנסת שם
                Button("Insert name") {
                    showNameInput = true
                }
                .foregroundColor(.blue)
                .underline()

                Spacer().frame(height: 10)

                // ברכת שלום
                Text("Hi \(userName.isEmpty ? "Guest" : userName)")
                    .font(.title)

                // הצגת צד לפי מיקום
                Text("You are on the \(userSide) Side")
                    .font(.subheadline)
                    .foregroundColor(.gray)

                Spacer().frame(height: 30)

                // תמונות חצאי כדור
                HStack {
                    VStack {
                        Image("earth_left")
                            .resizable()
                            .frame(width: 120, height: 120)
                        Text("West Side")
                    }

                    Spacer()

                    VStack {
                        Image("earth_right")
                            .resizable()
                            .frame(width: 120, height: 120)
                        Text("East Side")
                    }
                }
                .padding(.horizontal, 40)

                Spacer()

                // כפתור START
                Button("START") {
                    navigateToGame = true
                }
                .padding()
                .foregroundColor(.white)
                .frame(width: 200, height: 50)
                .background(Color.blue)
                .cornerRadius(10)

                Spacer()
            }
            .padding()
            .sheet(isPresented: $showNameInput) {
                NameInputView(name: $userName)
            }
            .onChange(of: locationManager.userLongitude) {
                if let long = locationManager.userLongitude {
                    userSide = long > centerLongitude ? "East" : "West"
                }
            }
            .navigationDestination(isPresented: $navigateToGame) {
                GameView()
            }
        }
    }
}

// מסך הכנסת שם
struct NameInputView: View {
    @Binding var name: String
    @Environment(\.dismiss) var dismiss

    var body: some View {
        VStack(spacing: 20) {
            Text("Enter your name")
                .font(.headline)

            TextField("Name", text: $name)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()

            Button("Save") {
                dismiss()
            }
            .padding()
            .foregroundColor(.white)
            .frame(width: 150, height: 40)
            .background(Color.green)
            .cornerRadius(10)
        }
        .padding()
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
